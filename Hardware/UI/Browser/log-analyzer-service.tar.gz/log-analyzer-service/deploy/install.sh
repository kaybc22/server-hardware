#!/bin/bash
# Back-compat wrapper. Use the root installer:
#   sudo bash install.sh
exec bash "$(cd "$(dirname "$0")/.." && pwd)/install.sh" "$@"
