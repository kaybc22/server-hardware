#!/bin/bash
# install.sh — packages + venv + hardened systemd/gunicorn unit
#   sudo bash install.sh
#   sudo LISTEN_PORT=5000 DEST_DIR=/opt/log-analyzer-service bash install.sh

set -euo pipefail

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
DEST_DIR="${DEST_DIR:-/opt/log-analyzer-service}"
APP_USER="${APP_USER:-loganalyzer}"
LISTEN_HOST="${LISTEN_HOST:-0.0.0.0}"
LISTEN_PORT="${LISTEN_PORT:-5000}"
ANALYZE_TIMEOUT="${ANALYZE_TIMEOUT:-300}"
UNIT_NAME="${UNIT_NAME:-log-analyzer}"
UNIT_PATH="/etc/systemd/system/${UNIT_NAME}.service"
GUNICORN_WORKERS=1
GUNICORN_THREADS="${GUNICORN_THREADS:-8}"

if [ "$(id -u)" -ne 0 ]; then
    echo "Run as root: sudo bash install.sh"
    exit 1
fi

echo "==> Installing OS packages"
if command -v apt-get >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq
    apt-get install -y -qq python3 python3-venv python3-pip tar unzip gzip bzip2 xz-utils findutils grep coreutils
elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 python3-pip tar unzip gzip bzip2 xz findutils grep coreutils
elif command -v yum >/dev/null 2>&1; then
    yum install -y python3 python3-pip tar unzip gzip bzip2 xz findutils grep coreutils
else
    echo "No apt/dnf/yum found. Ensure python3, tar, unzip, grep, find are installed."
fi

command -v python3 >/dev/null 2>&1 || { echo "Error: python3 is required."; exit 1; }

echo "==> Installing app to ${DEST_DIR}"
id -u "$APP_USER" >/dev/null 2>&1 || useradd --system --home "$DEST_DIR" --shell /usr/sbin/nologin "$APP_USER"

mkdir -p "$DEST_DIR"
if [ "$SRC_DIR" != "$DEST_DIR" ]; then
    if command -v rsync >/dev/null 2>&1; then
        rsync -a --delete \
            --exclude venv \
            --exclude uploads \
            --exclude '.git' \
            "$SRC_DIR/" "$DEST_DIR/"
    else
        cp -a "$SRC_DIR"/. "$DEST_DIR/"
        rm -rf "$DEST_DIR/venv"
    fi
fi

mkdir -p "$DEST_DIR/uploads" "$DEST_DIR/scripts" "$DEST_DIR/static"
chmod +x "$DEST_DIR/install.sh" "$DEST_DIR/start.sh" "$DEST_DIR/scripts/"*.sh 2>/dev/null || true

for script in analyze_logs.sh analyze_nvidia_bugreport.sh; do
    if [ ! -f "$DEST_DIR/scripts/$script" ]; then
        echo "Error: missing $DEST_DIR/scripts/$script"
        exit 1
    fi
done

echo "==> Creating venv and installing Flask/gunicorn"
if [ -d "$DEST_DIR/venv" ] && [ ! -x "$DEST_DIR/venv/bin/gunicorn" ]; then
    echo "Existing venv missing gunicorn; recreating..."
    rm -rf "$DEST_DIR/venv"
fi
if [ ! -d "$DEST_DIR/venv" ]; then
    python3 -m venv "$DEST_DIR/venv"
fi
"$DEST_DIR/venv/bin/pip" install -q --upgrade pip
"$DEST_DIR/venv/bin/pip" install -q -r "$DEST_DIR/requirements.txt"

chown -R "$APP_USER:$APP_USER" "$DEST_DIR"
chmod 750 "$DEST_DIR/uploads"

echo "==> Writing systemd unit ${UNIT_PATH}"
cat > "$UNIT_PATH" <<EOF
[Unit]
Description=Log Analyzer HTTP Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${APP_USER}
Group=${APP_USER}
WorkingDirectory=${DEST_DIR}
Environment=LISTEN_HOST=${LISTEN_HOST}
Environment=LISTEN_PORT=${LISTEN_PORT}
Environment=ANALYZE_TIMEOUT=${ANALYZE_TIMEOUT}
Environment=UPLOAD_DIR=${DEST_DIR}/uploads
Environment=HARDWARE_SCRIPT=${DEST_DIR}/scripts/analyze_logs.sh
Environment=NVIDIA_SCRIPT=${DEST_DIR}/scripts/analyze_nvidia_bugreport.sh
Environment=PYTHONUNBUFFERED=1
ExecStart=${DEST_DIR}/venv/bin/gunicorn --bind ${LISTEN_HOST}:${LISTEN_PORT} --workers ${GUNICORN_WORKERS} --threads ${GUNICORN_THREADS} --timeout ${ANALYZE_TIMEOUT} --graceful-timeout 30 --keep-alive 5 --access-logfile - --error-logfile - --capture-output server:app
ExecReload=/bin/kill -s HUP \$MAINPID
Restart=on-failure
RestartSec=5
TimeoutStartSec=60
TimeoutStopSec=30
KillMode=mixed
KillSignal=SIGTERM
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${DEST_DIR}/uploads
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
LockPersonality=true
RestrictSUIDSGID=true
RestrictRealtime=true
MemoryMax=1G
LimitNOFILE=4096

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now "${UNIT_NAME}.service"
systemctl restart "${UNIT_NAME}.service"

sleep 1
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo
echo "Installed and started."
echo "  service: systemctl status ${UNIT_NAME} --no-pager"
echo "  logs:    journalctl -u ${UNIT_NAME} -f"
echo "  url:     http://${IP:-<server-ip>}:${LISTEN_PORT}"
echo "  health:  curl -sS http://127.0.0.1:${LISTEN_PORT}/health"
echo
if command -v ss >/dev/null 2>&1; then
    ss -lntp | grep -E ":${LISTEN_PORT}\\b" || true
fi
systemctl --no-pager --full status "${UNIT_NAME}.service" || true
curl -sS "http://127.0.0.1:${LISTEN_PORT}/health" || echo "health check not ready yet"
echo
