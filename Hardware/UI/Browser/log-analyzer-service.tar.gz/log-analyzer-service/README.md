# Log Analyzer Service

A lightweight web service that wraps `analyze_logs.sh` with a browser UI.  
Upload a log archive, click **Analyze Logs**, and see colorized results instantly.

---

## Folder Structure

```
log-analyzer-service/
├── server.py              # Flask web server (backend)
├── start.sh               # One-command launcher
├── requirements.txt       # Python dependencies (flask)
├── scripts/
│   └── analyze_logs.sh    # Your existing analysis script
│   └── analyze_nvidia_bugreport #
├── static/
│   └── index.html         # Web UI
└── uploads/               # Temp upload directory (auto-cleaned)
```

---

## Quick Start

### 1. Prerequisites

- Python 3.8+
- `pip3`
- Standard Linux tools already used by the script: `tar`, `unzip`, `grep`, `find`

### 2. First Run

```bash
cd log-analyzer-service
bash start.sh
```

This installs Flask (first run only) and starts the server.

### 3. Open the UI

Navigate to **http://localhost:5000** in any browser on the same machine.  
If accessing from another machine on the network: **http://<server-ip>:5000**

---

## Usage

1. **Drop or browse** a log archive (`.log`, `.zip`, `.tgz`, `.tar.gz`, `.tar.bz2`, `.tar.xz`)
2. Click **Analyze Logs**
3. Results appear with:
   - Summary cards (Total / Pass / Fail counts)
   - Color-coded log output (green = OK, red = errors, yellow = warnings)
   - **Copy Output** button to grab the full text

---

## Running as a System Service

```bash
cd log-analyzer-service
sudo bash install.sh
```

This installs OS packages, creates `/opt/log-analyzer-service`, a `loganalyzer` user, a venv with Flask + gunicorn, and enables `log-analyzer.service`.

```bash
systemctl status log-analyzer --no-pager
journalctl -u log-analyzer -f
curl -sS http://127.0.0.1:5000/health
```

`/health` returns JSON (`status=ok` or `degraded`) and HTTP 200/503. Gunicorn is started with **1 worker / 8 threads** because job state is in-memory.

Foreground (no systemd): `bash start.sh`

---

## Configuration

Edit `server.py` to change:

| Setting | Default | Description |
|---|---|---|
| `port` | `5000` | Web server port |
| `host` | `0.0.0.0` | Listen on all interfaces |
| `timeout` | `300s` | Max analysis time per job |

---

## Security Note

This service is intended for use on a trusted internal network.  
Do not expose port 5000 to the public internet without adding authentication.
