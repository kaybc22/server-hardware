#!/usr/bin/env python3
"""
Log Analyzer Service
Supports two analyzers:
  1. analyze_logs.sh              — server hardware run logs
  2. analyze_nvidia_bugreport.sh  — NVIDIA bug report logs
"""

import os
import re
import subprocess
import threading
import time
import uuid
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

app = Flask(__name__, static_folder="static", template_folder="static")

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR", BASE_DIR / "uploads"))
SCRIPTS_DIR = BASE_DIR / "scripts"

HOST = os.environ.get("LISTEN_HOST", "0.0.0.0")
PORT = int(os.environ.get("LISTEN_PORT", "5000"))
TIMEOUT = int(os.environ.get("ANALYZE_TIMEOUT", "300"))
STARTED_AT = time.time()

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

ANALYZERS = {
    "hardware": {
        "script": Path(os.environ.get("HARDWARE_SCRIPT", SCRIPTS_DIR / "analyze_logs.sh")),
        "allowed": {".log", ".zip", ".tgz", ".tar.gz", ".tar.bz2", ".tar.xz", ".tar", ".tbz2", ".txz"},
    },
    "nvidia": {
        "script": Path(os.environ.get("NVIDIA_SCRIPT", SCRIPTS_DIR / "analyze_nvidia_bugreport.sh")),
        "allowed": {".log", ".gz", ".log.gz", ".zip", ".tgz", ".tar.gz", ".tar.bz2", ".tar.xz", ".tar", ".tbz2", ".txz"},
    },
}

jobs: dict = {}
jobs_lock = threading.Lock()
JOB_TTL_SEC = int(os.environ.get("JOB_TTL_SEC", "3600"))


def allowed_file(filename: str, analyzer: str) -> bool:
    name = filename.lower()
    return any(name.endswith(ext) for ext in ANALYZERS[analyzer]["allowed"])


def strip_ansi(text: str) -> str:
    return re.sub(r"\x1b\[[0-9;]*m", "", text)


def prune_jobs():
    cutoff = time.time() - JOB_TTL_SEC
    with jobs_lock:
        stale = [jid for jid, job in jobs.items() if job.get("updated", 0) < cutoff]
        for jid in stale:
            jobs.pop(jid, None)


def run_analysis(job_id: str, file_path: Path, analyzer: str):
    script = ANALYZERS[analyzer]["script"]
    try:
        if not script.is_file():
            raise FileNotFoundError(f"Analyzer script missing: {script}")
        result = subprocess.run(
            ["bash", str(script), str(file_path)],
            capture_output=True,
            text=True,
            timeout=TIMEOUT,
            cwd=str(UPLOAD_DIR),
        )
        raw = result.stdout + (("\n[stderr]\n" + result.stderr) if result.stderr.strip() else "")
        clean = strip_ansi(raw)
        with jobs_lock:
            jobs[job_id]["status"] = "done"
            jobs[job_id]["output"] = clean
            jobs[job_id]["returncode"] = result.returncode
            jobs[job_id]["updated"] = time.time()
    except subprocess.TimeoutExpired:
        with jobs_lock:
            jobs[job_id]["status"] = "error"
            jobs[job_id]["output"] = f"Error: Analysis timed out after {TIMEOUT} seconds."
            jobs[job_id]["updated"] = time.time()
    except Exception as e:
        with jobs_lock:
            jobs[job_id]["status"] = "error"
            jobs[job_id]["output"] = f"Error running analysis: {e}"
            jobs[job_id]["updated"] = time.time()
    finally:
        try:
            file_path.unlink(missing_ok=True)
        except Exception:
            pass
        prune_jobs()


@app.route("/")
def index():
    return send_from_directory("static", "index.html")


@app.route("/health")
def health():
    scripts = {}
    ready = True
    for name, cfg in ANALYZERS.items():
        path = cfg["script"]
        exists = path.is_file()
        scripts[name] = {"path": str(path), "exists": exists}
        if not exists:
            ready = False
    payload = {
        "status": "ok" if ready else "degraded",
        "uptime_sec": int(time.time() - STARTED_AT),
        "listen": f"{HOST}:{PORT}",
        "timeout_sec": TIMEOUT,
        "upload_dir": str(UPLOAD_DIR),
        "upload_dir_writable": os.access(UPLOAD_DIR, os.W_OK),
        "scripts": scripts,
        "jobs": {
            "tracked": len(jobs),
            "running": sum(1 for j in jobs.values() if j.get("status") == "running"),
        },
    }
    return jsonify(payload), (200 if ready else 503)


@app.route("/upload", methods=["POST"])
def upload():
    prune_jobs()
    analyzer = request.form.get("analyzer", "hardware")
    if analyzer not in ANALYZERS:
        return jsonify({"error": f"Unknown analyzer '{analyzer}'"}), 400

    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "Empty filename"}), 400

    filename = file.filename
    if not allowed_file(filename, analyzer):
        allowed = ", ".join(sorted(ANALYZERS[analyzer]["allowed"]))
        return jsonify({"error": f"Unsupported file type. Allowed: {allowed}"}), 400

    safe_name = re.sub(r"[^a-zA-Z0-9._\-]", "_", filename)
    unique_name = f"{uuid.uuid4().hex[:8]}_{safe_name}"
    file_path = UPLOAD_DIR / unique_name
    file.save(str(file_path))

    job_id = uuid.uuid4().hex
    with jobs_lock:
        jobs[job_id] = {
            "status": "running",
            "output": "",
            "filename": filename,
            "analyzer": analyzer,
            "returncode": None,
            "updated": time.time(),
        }

    thread = threading.Thread(target=run_analysis, args=(job_id, file_path, analyzer), daemon=True)
    thread.start()

    return jsonify({"job_id": job_id, "filename": filename, "analyzer": analyzer})


@app.route("/status/<job_id>")
def status(job_id: str):
    with jobs_lock:
        job = jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify({k: v for k, v in job.items() if k != "updated"})


if __name__ == "__main__":
    print("=" * 50)
    print(" Log Analyzer Service")
    print(f" Open http://localhost:{PORT}")
    print(f" Health http://127.0.0.1:{PORT}/health")
    print("=" * 50)
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
