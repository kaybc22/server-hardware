#!/bin/bash

# =============================================================================
# analyze_nvidia_bugreport.sh
#
# Analyzes a single large nvidia-bug-report log file (plain text or compressed).
# Supports: .gz, .tar.gz, .tgz, .tar.bz2, .tbz2, .tar.xz, .txz, .tar, .zip
#
# Usage:
#   bash analyze_nvidia_bugreport.sh <log_file>
#
# Examples:
#   bash analyze_nvidia_bugreport.sh nvidia-bug-report.log.gz
#   bash analyze_nvidia_bugreport.sh nvidia-bug-report.log
# =============================================================================

# --- Configuration ---
LOG_INPUT="$1"

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# --- Helper: print a section header ---
print_section() {
    local title="$1"
    echo ""
    echo -e "${CYAN}${BOLD}=================================================================${NC}"
    echo -e "${CYAN}${BOLD}  $title${NC}"
    echo -e "${CYAN}${BOLD}=================================================================${NC}"
}

# --- Helper: print result block ---
print_result() {
    local label="$1"
    local content="$2"
    local found="$3"   # "ok" | "warn" | "info"

    echo ""
    echo -e "${BOLD}>>> $label${NC}"
    if [ -z "$content" ]; then
        echo -e "${GREEN}  [No matching entries found]${NC}"
    else
        local count
        count=$(echo "$content" | wc -l)
        case "$found" in
            warn) echo -e "${RED}  [$count line(s) found]${NC}"
                  echo -e "${RED}${content}${NC}" ;;
            ok)   echo -e "${GREEN}  [$count line(s) found]${NC}"
                  echo -e "${GREEN}${content}${NC}" ;;
            *)    echo -e "${YELLOW}  [$count line(s) found]${NC}"
                  echo "$content" ;;
        esac
    fi
}

# --- Extraction Function ---
# Decompresses/extracts the input file into dest_dir.
# For plain .log files, copies directly.
extract_log() {
    local input_path="$1"
    local dest_dir="$2"
    local filename="${input_path##*/}"

    case "$filename" in
        *.log.gz|*.gz)
            echo "Detected .gz file. Decompressing..."
            gzip -dc "$input_path" > "$dest_dir/bugreport.log"
            ;;
        *.tar.gz|*.tgz)
            echo "Detected .tar.gz / .tgz archive. Extracting..."
            tar -xzf "$input_path" -C "$dest_dir"
            ;;
        *.tar.bz2|*.tbz2)
            echo "Detected .tar.bz2 / .tbz2 archive. Extracting..."
            tar -xjf "$input_path" -C "$dest_dir"
            ;;
        *.tar.xz|*.txz)
            echo "Detected .tar.xz / .txz archive. Extracting..."
            tar -xJf "$input_path" -C "$dest_dir"
            ;;
        *.tar)
            echo "Detected .tar archive. Extracting..."
            tar -xf "$input_path" -C "$dest_dir"
            ;;
        *.zip)
            echo "Detected .zip archive. Extracting..."
            unzip -q "$input_path" -d "$dest_dir"
            ;;
        *.log|*.txt)
            echo "Detected plain text log file. Copying..."
            cp "$input_path" "$dest_dir/bugreport.log"
            ;;
        *)
            echo "Error: Unsupported file format '$filename'."
            echo "Supported: .gz, .log, .txt, .tar.gz, .tgz, .tar.bz2, .tbz2, .tar.xz, .txz, .tar, .zip"
            return 1
            ;;
    esac
    return $?
}

# --- locate_log: find the extracted plain-text log file ---
locate_log() {
    local search_dir="$1"
    # Prefer nvidia-bug-report.log, then any .log, then any file
    local found
    found=$(find "$search_dir" -type f -name "nvidia-bug-report.log" | head -n 1)
    [ -z "$found" ] && found=$(find "$search_dir" -type f -name "*.log" | head -n 1)
    [ -z "$found" ] && found=$(find "$search_dir" -type f | head -n 1)
    echo "$found"
}

# =============================================================================
# --- Script Entry Point ---
# =============================================================================

if [ -z "$LOG_INPUT" ]; then
    echo "Usage: $0 <log_file>"
    echo ""
    echo "Examples:"
    echo "  $0 nvidia-bug-report.log.gz"
    echo "  $0 nvidia-bug-report.log"
    echo "  $0 nvidia-bug-report.tgz"
    exit 1
fi

if [ ! -f "$LOG_INPUT" ]; then
    echo "Error: File '$LOG_INPUT' not found."
    exit 1
fi

# Create temp directory and ensure cleanup on exit
TEMP_DIR=$(mktemp -d -t nvidia_bugreport_XXXXXX)
if [ $? -ne 0 ]; then
    echo "Error: Could not create temporary directory."
    exit 1
fi
echo "Created temporary directory: $TEMP_DIR"
trap "echo 'Cleaning up temporary directory: $TEMP_DIR'; rm -rf '$TEMP_DIR'" EXIT

# Extract / decompress
echo "Processing '$LOG_INPUT'..."
if ! extract_log "$LOG_INPUT" "$TEMP_DIR"; then
    echo "Error: Failed to process '$LOG_INPUT'."
    exit 1
fi

# Locate the plain-text log inside the extracted directory
LOG_FILE=$(locate_log "$TEMP_DIR")
if [ -z "$LOG_FILE" ]; then
    echo "Error: Could not find a readable log file inside '$LOG_INPUT'."
    exit 1
fi

echo "Analyzing log file: $LOG_FILE"
FILE_SIZE=$(wc -c < "$LOG_FILE")
echo "File size: $FILE_SIZE bytes"

# =============================================================================
# --- Analysis ---
# =============================================================================

print_section "NVIDIA Bug Report Analysis: ${LOG_INPUT##*/}"
echo "Log file : $LOG_FILE"
echo "File size: $FILE_SIZE bytes"

# --- 1. lspci | grep -i nvidia ---
print_section "1. lspci | grep -i nvidia"
LSPCI_NVIDIA=$(grep "NVIDIA Corporation" "$LOG_FILE" 2>/dev/null)
if [ -n "$LSPCI_NVIDIA" ]; then
    print_result "lspci | grep -i nvidia" "$LSPCI_NVIDIA" "ok"
else
    echo -e "${YELLOW}  No matching entries found.${NC}"
fi

# --- 2. dmesg | grep NVRM ---
print_section "2. dmesg | grep NVRM"
NVRM=$(grep "NVRM:" "$LOG_FILE" 2>/dev/null)
if [ -n "$NVRM" ]; then
    print_result "dmesg | grep NVRM" "$NVRM" "info"
else
    echo -e "${YELLOW}  No matching entries found.${NC}"
fi

# --- 3. egrep "Remapping Failure Occurred|SRAM Threshold Exceeded" ---
print_section "3. egrep \"Remapping Failure Occurred|SRAM Threshold Exceeded\""
REMAP=$(grep -E "Remapping Failure Occurred|SRAM Threshold Exceeded" "$LOG_FILE" 2>/dev/null)
if [ -n "$REMAP" ]; then
    print_result "Remapping / SRAM issues" "$REMAP" "warn"
else
    echo -e "${GREEN}  No matching entries found.${NC}"
fi

# =============================================================================
# --- Summary ---
# =============================================================================
print_section "Analysis Summary"

ISSUE_COUNT=0

if [ -z "$LSPCI_NVIDIA" ]; then
    echo -e "${YELLOW}  [WARN] No NVIDIA PCI devices detected in log.${NC}"
    ISSUE_COUNT=$((ISSUE_COUNT + 1))
else
    DEVICE_COUNT=$(echo "$LSPCI_NVIDIA" | wc -l)
    echo -e "${GREEN}  [OK]   $DEVICE_COUNT NVIDIA PCI line(s) found.${NC}"
fi

if [ -n "$NVRM" ]; then
    NVRM_COUNT=$(echo "$NVRM" | wc -l)
    echo -e "${GREEN}  [OK]   $NVRM_COUNT NVRM line(s) found.${NC}"
else
    echo -e "${YELLOW}  [WARN] No NVRM messages found.${NC}"
fi

if [ -n "$REMAP" ]; then
    REMAP_COUNT=$(echo "$REMAP" | wc -l)
    echo -e "${RED}  [FAIL] $REMAP_COUNT Remapping/SRAM issue line(s) found.${NC}"
    ISSUE_COUNT=$((ISSUE_COUNT + REMAP_COUNT))
else
    echo -e "${GREEN}  [OK]   No Remapping Failure or SRAM Threshold issues detected.${NC}"
fi

echo ""
if [ "$ISSUE_COUNT" -eq 0 ]; then
    echo -e "${GREEN}${BOLD}  Overall: No issues detected.${NC}"
else
    echo -e "${RED}${BOLD}  Overall: $ISSUE_COUNT issue(s) detected. Review details above.${NC}"
fi

echo ""
echo "-------------------------------------"
