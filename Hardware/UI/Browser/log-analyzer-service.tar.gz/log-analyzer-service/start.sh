#!/bin/bash
# start.sh — venv + gunicorn (foreground). For systemd use install.sh.

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

VENV_DIR="$SCRIPT_DIR/venv"
LISTEN_HOST="${LISTEN_HOST:-0.0.0.0}"
LISTEN_PORT="${LISTEN_PORT:-5000}"
ANALYZE_TIMEOUT="${ANALYZE_TIMEOUT:-300}"
GUNICORN_WORKERS="${GUNICORN_WORKERS:-1}"
GUNICORN_THREADS="${GUNICORN_THREADS:-8}"

if ! command -v python3 >/dev/null 2>&1; then
    echo "Error: python3 is required but not found."
    exit 1
fi

mkdir -p "$SCRIPT_DIR/uploads"
chmod +x "$SCRIPT_DIR/scripts/"*.sh 2>/dev/null || true

if [ -d "$VENV_DIR" ] && [ ! -f "$VENV_DIR/bin/pip" ]; then
    echo "Detected incomplete virtual environment. Removing and recreating..."
    rm -rf "$VENV_DIR"
fi

if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment..."
    if ! python3 -m venv "$VENV_DIR"; then
        echo "Error: Failed to create virtual environment."
        echo "On Debian/Ubuntu: sudo apt install python3-venv python3-full"
        exit 1
    fi
fi

echo "Checking dependencies..."
"$VENV_DIR/bin/pip" install -q --upgrade pip
"$VENV_DIR/bin/pip" install -q -r requirements.txt

export LISTEN_HOST LISTEN_PORT ANALYZE_TIMEOUT
export UPLOAD_DIR="${UPLOAD_DIR:-$SCRIPT_DIR/uploads}"

echo ""
echo "============================================"
echo "  Log Analyzer Service (gunicorn)"
echo "  http://${LISTEN_HOST}:${LISTEN_PORT}"
echo "  health: http://127.0.0.1:${LISTEN_PORT}/health"
echo "  workers=${GUNICORN_WORKERS} threads=${GUNICORN_THREADS} (keep workers=1; jobs are in-memory)"
echo "  Press Ctrl+C to stop"
echo "============================================"
echo ""

if [ "${USE_FLASK_DEV:-0}" = "1" ]; then
    exec "$VENV_DIR/bin/python" server.py
fi

exec "$VENV_DIR/bin/gunicorn" \
    --bind "${LISTEN_HOST}:${LISTEN_PORT}" \
    --workers "${GUNICORN_WORKERS}" \
    --threads "${GUNICORN_THREADS}" \
    --timeout "${ANALYZE_TIMEOUT}" \
    --graceful-timeout 30 \
    --keep-alive 5 \
    --access-logfile - \
    --error-logfile - \
    --capture-output \
    server:app
